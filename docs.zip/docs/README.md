# Project Documentation

## Project Planning

- [Project plan and task breakdown](PROJECT_PLAN.md)
- [Feature specification](FEATURE_SPEC.md)
- [Repository structure](REPO_STRUCTURE.md)
- [GitHub workflow](GITHUB_WORKFLOW.md)

## Data Science and Data Engineering

- [Data and database plan](DATA_AND_DATABASE.md)
- [Data audit](data/DATA_AUDIT.md)
- [Data dictionary](data/DATA_DICTIONARY.md)
- [SQL and Python analytics plan](ANALYTICS_PLAN.md)
- [Machine learning plan](ML_PLAN.md)

## Software Engineering

- [Software engineering documentation index](software-engineering/README.md)
- [Software Requirements Specification](software-engineering/REQUIREMENTS_SPECIFICATION.md)
- [System Analysis and Design Deliverables Coverage](software-engineering/SYSTEM_ANALYSIS_DELIVERABLES.md)
- [Project diagram pack](diagrams/README.md)
- [Web application plan](WEB_APP_PLAN.md)

The software engineering index covers requirements, user stories, use cases, architecture, API and database specifications, UX, accessibility, localization, security, testing, deployment, development workflow, traceability, risks, and decision records.
